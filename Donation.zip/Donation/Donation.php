<!DOCTYPE html>
<html>
<head>
<title>Donation Form </title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet" />
 <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container theme-background-white main-body">
      <div class="col-md-12">
        <div class="row donate-bar">  
          <div class="col-md-4 theme-blue">
            GIVE WHERE NEEDED MOST
          </div>
          <div class="col-md-8">
            <ul class="nav navbar-nav navbar-left donate-buttons" id="donate-buttons">
              <li><a href="#">
                <button class="btn-blue active" data-dollars='25' data-impact="Covers housing or counseling services for one person">
                  ₹25
                </button>
              </a></li>
              <li><a href="#">
                <button class="btn-blue" data-dollars='50' data-impact="Covers housing or counseling services for two people">
                  ₹50
                </button>
              </a></li>
              <li><a href="#">
                <button class="btn-blue" data-dollars='100' data-impact="Covers housing or counseling services for four people">
                  ₹100
                </button>
              </a></li>
              <li><a href="#">
                <button class="btn-blue" data-dollars='500' data-impact="Covers housing or counseling services for twenty people">
                  ₹500
                </button>
              </a></li>
              <li id="other"><a href="#">
                <button class="btn-blue-other" data-dollars='other' data-impact="Thank you!">
                  OTHER
                </button>
              </a></li>
              <li id="other-input">
                <span>₹</span>
               <input data-impact="That’s great. Thank you!">
              </li>
              <li><a href="#">
                <button class="btn-green" data-toggle="modal" data-target="#myModal">
                  DONATE
                </button>
              </a></li>
              <li style="display: none;"><a href="#">
                LEARN MORE<i class="fa fa-chevron-right margin-left"></i>
              </a></li>
            </ul>
            <p class="impact">
              Covers housing or counseling services for one person
            </p>
            <!-- Modal -->
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header well text-center theme-background-blue">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                    <h2>You’re Donating:</h2>
                    <h1 style="font-size: 5.5em; margin-top: 0;">₹<span id="price"></span></h1>
                    <em>Thank you!</em>
                  </div>
                  <div class="modal-body">
                    <div class="row">  
                      <section class="col-md-12">
                        <form>
                          <fieldset class="col-md-6">
                            <legend>
                              Your personal info
                            </legend>
                            <label>Your Name</label>
                            <input type="string" class="form-control">
                            <label>Your email</label>
                            <input type="email" class="form-control">
                            <label>Address</label>
                            <input type="email" class="form-control">
                            <label>City, State, Zip Code</label>
                            <input type="email" class="form-control">
                          </fieldset>
                          <fieldset class="col-md-6">
                            <legend>
                              Credit Card Information
                            </legend>
                            <label for="card-number">Credit Card Number</label>
                            <input placeholder="1234 5678 9012 3456" pattern="[0-9]*" type="text" class="form-control card-number" id="card-number">
                            <label for="card-number">Expiration Date</label>
                            <input placeholder="MM/YY" pattern="[0-9]*" type="text" class="form-control card-expiration" id="card-expiration">
                            <label for="card-number">CVV Number</label>
                            <input placeholder="CVV" pattern="[0-9]*" type="text" class="form-control card-cvv" id="card-cvv">
                            <label for="card-number">Billing Zip Code</label>
                            <input placeholder="ZIP" pattern="[0-9]*" type="text" class="form-control card-zip" id="card-zip">
                          </fieldset>
                        </form>
                      </section>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">BACK</button>
                    <button type="button" class="btn-green">CONTINUE</button>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
          </div>
        </div><!--/.donate-bar-->
      </div><!-- /.col-md-12 -->

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
      
<script>
$(document).ready(function(){

        $('#searchbar').focus();

        $('#donate-buttons').on('click', '.btn-blue', function(e) {
          e.preventDefault();
          $('.active').removeClass('active');
          $('#other-input').hide().siblings('#other').show();
          $(this).filter('.btn-blue').addClass("active");
          var value = $(this).data('impact');
          $(this).closest('div').find('p').text("" + value);
          $('#other-input').find('input').val('');  
        });
          
        $('.btn-green').on('click', function() {
          var dollar;
          var input = $('#other-input').find('input').val();
          if ( !input ) {
            dollar = $('.active').data('dollars');
           } else if ( $.trim(input) === '' || isNaN(input)) {
            // empty space leaves value = 'undefined'. 
            // Have to fix $.trim(input) == '' above so that it works.
            console.log('Yes');
            dollar = "Please enter a number."; 
          } else {
            dollar = input;
          }
          $('#price').text(""+dollar);
        });

        $('#other').on('click', function(e) {
          e.preventDefault(); 
          var buttons = $(this).parent('#donate-buttons');
          buttons.find('.active').removeClass('active');
          var other = $(this).hide().siblings('#other-input');
          other.show();
          other.find('input').focus();
          var pText = buttons.siblings('p');
          pText.text("Thank you!");
          var oValue = other.find('input');
          oValue.keyup(function() {
            if ( oValue.val() > 50 ) {
              pText.text("Thank you!" + " You\'re donation covers housing and counseling services for " + oValue.val()/25 + " people.");
            } else {
              pText.text("Thank you!");
            }
          });
        }); 

      });
</script>

</body>
</html>
